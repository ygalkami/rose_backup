#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "common.h"
#include "builtin.h"
#include "process_handler.h"
#include "env_variables.h"

#ifndef INPUT_PARSE_H
#define INPUT_PARSE_H

int parse_input(char* ret);

#endif
