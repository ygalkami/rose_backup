#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "common.h"

#ifndef ENV_VARIABLES_H
#define ENV_VARIABLES_H

void env_add(char *var, char *replace);

void env_remove(char *var);

void env_init();

#endif
